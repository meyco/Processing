def return_twelve():
    return 12