size(11, 13)
assert(width == 11)
assert(height == 13)
print 'OK'
exit()
