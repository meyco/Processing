assert lerpColor(0, 100, .5) == 50
print 'OK'
exit()
